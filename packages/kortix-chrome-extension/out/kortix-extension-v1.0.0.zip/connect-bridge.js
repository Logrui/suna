const ENV = {
  FRONTEND_URL: "https://suna.syhc.dev",
  BACKEND_URL: "https://api.suna.syhc.dev/v1"
};
function getFrontendOrigin() {
  try {
    return new URL(ENV.FRONTEND_URL).origin;
  } catch {
    return ENV.FRONTEND_URL;
  }
}
function getConfig() {
  return {
    apiUrl: ENV.BACKEND_URL.endsWith("/v1") ? ENV.BACKEND_URL.slice(0, -3) : ENV.BACKEND_URL,
    wsUrl: ENV.BACKEND_URL.replace(/^http/, "wss://") + "/ws/extension",
    frontendUrl: ENV.FRONTEND_URL
  };
}
function isExtensionContextValid() {
  try {
    chrome.runtime.getManifest();
    return true;
  } catch (e) {
    return false;
  }
}
function notifyRefreshRequired(origin = "*") {
  window.postMessage({
    type: "KORTIX_EXTENSION_REFRESH_REQUIRED",
    message: "Extension was reloaded. Please refresh this page."
  }, origin);
  console.warn("[Kortix Extension - Bridge] Extension context invalidated. Please refresh the page.");
}
function setupTokenListener() {
  window.addEventListener("message", async (event) => {
    if (!isExtensionContextValid()) {
      notifyRefreshRequired(event.origin);
      return;
    }
    const config2 = getConfig();
    const allowedOrigins = [
      config2.frontendUrl,
      getFrontendOrigin(),
      // Ensure we have the base origin
      "http://localhost:3000"
    ];
    const originUrl = new URL(event.origin).origin;
    const isAllowed = allowedOrigins.some((allowed) => {
      try {
        return new URL(allowed).origin === originUrl;
      } catch {
        return false;
      }
    });
    if (!isAllowed) {
      return;
    }
    const data = event.data;
    if (data.type === "KORTIX_BROWSER_TOKEN" && data.token) {
      console.log("[Kortix Extension - Bridge] Received browser token");
      try {
        const response = await chrome.runtime.sendMessage({
          type: "connect",
          token: data.token
        });
        if (response.success) {
          console.log("[Kortix Extension - Bridge] Token sent to background, connecting...");
          window.postMessage({
            type: "KORTIX_EXTENSION_CONNECTED",
            success: true
          }, event.origin);
        } else {
          console.error("[Kortix Extension - Bridge] Connection failed:", response.error);
          window.postMessage({
            type: "KORTIX_EXTENSION_CONNECTED",
            success: false,
            error: response.error
          }, event.origin);
        }
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : "Unknown error";
        if (errorMsg.includes("Extension context invalidated") || !isExtensionContextValid()) {
          notifyRefreshRequired(event.origin);
          return;
        }
        console.error("[Kortix Extension - Bridge] Error sending token:", error);
        window.postMessage({
          type: "KORTIX_EXTENSION_CONNECTED",
          success: false,
          error: errorMsg
        }, event.origin);
      }
    }
    if (event.data.type === "KORTIX_CHECK_EXTENSION") {
      const status = await getExtensionStatus();
      window.postMessage(status, event.origin);
    }
    if (event.data.type === "KORTIX_DISCONNECT_EXTENSION") {
      console.log("[Kortix Extension - Bridge] Received disconnect request");
      try {
        const response = await chrome.runtime.sendMessage({ type: "disconnect" });
        if (response.success) {
          console.log("[Kortix Extension - Bridge] Disconnected successfully");
          window.postMessage({
            type: "KORTIX_EXTENSION_DISCONNECTED",
            success: true
          }, event.origin);
        } else {
          console.error("[Kortix Extension - Bridge] Disconnect failed:", response.error);
          window.postMessage({
            type: "KORTIX_EXTENSION_DISCONNECTED",
            success: false,
            error: response.error
          }, event.origin);
        }
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : "Unknown error";
        if (errorMsg.includes("Extension context invalidated") || !isExtensionContextValid()) {
          notifyRefreshRequired(event.origin);
          return;
        }
        console.error("[Kortix Extension - Bridge] Error disconnecting:", error);
        window.postMessage({
          type: "KORTIX_EXTENSION_DISCONNECTED",
          success: false,
          error: errorMsg
        }, event.origin);
      }
    }
  });
}
async function getExtensionStatus() {
  if (!isExtensionContextValid()) {
    return {
      type: "KORTIX_EXTENSION_STATUS",
      installed: true,
      connected: false,
      extensionId: null,
      needsRefresh: true
    };
  }
  try {
    const response = await chrome.runtime.sendMessage({ type: "getStatus" });
    return {
      type: "KORTIX_EXTENSION_STATUS",
      installed: true,
      connected: response.isConnected,
      extensionId: response.extensionId
    };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : "";
    if (errorMsg.includes("Extension context invalidated")) {
      return {
        type: "KORTIX_EXTENSION_STATUS",
        installed: true,
        connected: false,
        extensionId: null,
        needsRefresh: true
      };
    }
    return {
      type: "KORTIX_EXTENSION_STATUS",
      installed: true,
      connected: false,
      extensionId: null
    };
  }
}
function announcePresence() {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      sendPresenceAnnouncement();
    });
  } else {
    sendPresenceAnnouncement();
  }
}
async function sendPresenceAnnouncement() {
  const status = await getExtensionStatus();
  window.postMessage(status, "*");
  console.log("[Kortix Extension - Bridge] Announced presence to page");
}
console.log("[Kortix Extension - Bridge] Content script loaded on:", window.location.href);
const frontendOrigin = getFrontendOrigin();
const isKortixPage = window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1" || frontendOrigin && window.location.origin === frontendOrigin;
console.log("[Kortix Extension - Bridge] isKortixPage:", isKortixPage, "hostname:", window.location.hostname);
if (isKortixPage) {
  console.log("[Kortix Extension - Bridge] Running on Kortix page - setting up listeners");
  setupTokenListener();
  announcePresence();
} else {
  console.log("[Kortix Extension - Bridge] Not a Kortix page, skipping setup");
}
