var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
var extendStatics = function(d, b) {
  extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
    d2.__proto__ = b2;
  } || function(d2, b2) {
    for (var p in b2) if (b2.hasOwnProperty(p)) d2[p] = b2[p];
  };
  return extendStatics(d, b);
};
function __extends(d, b) {
  extendStatics(d, b);
  function __() {
    this.constructor = d;
  }
  d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
function __values(o) {
  var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
  if (m) return m.call(o);
  return {
    next: function() {
      if (o && i >= o.length) o = void 0;
      return { value: o && o[i++], done: !o };
    }
  };
}
function __read(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m) return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"])) m.call(i);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
}
function __spread() {
  for (var ar = [], i = 0; i < arguments.length; i++)
    ar = ar.concat(__read(arguments[i]));
  return ar;
}
var Event = (
  /** @class */
  /* @__PURE__ */ function() {
    function Event2(type, target) {
      this.target = target;
      this.type = type;
    }
    return Event2;
  }()
);
var ErrorEvent = (
  /** @class */
  function(_super) {
    __extends(ErrorEvent2, _super);
    function ErrorEvent2(error, target) {
      var _this = _super.call(this, "error", target) || this;
      _this.message = error.message;
      _this.error = error;
      return _this;
    }
    return ErrorEvent2;
  }(Event)
);
var CloseEvent = (
  /** @class */
  function(_super) {
    __extends(CloseEvent2, _super);
    function CloseEvent2(code, reason, target) {
      if (code === void 0) {
        code = 1e3;
      }
      if (reason === void 0) {
        reason = "";
      }
      var _this = _super.call(this, "close", target) || this;
      _this.wasClean = true;
      _this.code = code;
      _this.reason = reason;
      return _this;
    }
    return CloseEvent2;
  }(Event)
);
/*!
 * Reconnecting WebSocket
 * by Pedro Ladaria <pedro.ladaria@gmail.com>
 * https://github.com/pladaria/reconnecting-websocket
 * License MIT
 */
var getGlobalWebSocket = function() {
  if (typeof WebSocket !== "undefined") {
    return WebSocket;
  }
};
var isWebSocket = function(w) {
  return typeof w !== "undefined" && !!w && w.CLOSING === 2;
};
var DEFAULT = {
  maxReconnectionDelay: 1e4,
  minReconnectionDelay: 1e3 + Math.random() * 4e3,
  minUptime: 5e3,
  reconnectionDelayGrowFactor: 1.3,
  connectionTimeout: 4e3,
  maxRetries: Infinity,
  maxEnqueuedMessages: Infinity
};
var ReconnectingWebSocket = (
  /** @class */
  function() {
    function ReconnectingWebSocket2(url, protocols, options) {
      var _this = this;
      if (options === void 0) {
        options = {};
      }
      this._listeners = {
        error: [],
        message: [],
        open: [],
        close: []
      };
      this._retryCount = -1;
      this._shouldReconnect = true;
      this._connectLock = false;
      this._binaryType = "blob";
      this._closeCalled = false;
      this._messageQueue = [];
      this.onclose = null;
      this.onerror = null;
      this.onmessage = null;
      this.onopen = null;
      this._handleOpen = function(event) {
        _this._debug("open event");
        var _a = _this._options.minUptime, minUptime = _a === void 0 ? DEFAULT.minUptime : _a;
        clearTimeout(_this._connectTimeout);
        _this._uptimeTimeout = setTimeout(function() {
          return _this._acceptOpen();
        }, minUptime);
        _this._ws.binaryType = _this._binaryType;
        _this._messageQueue.forEach(function(message) {
          return _this._ws.send(message);
        });
        _this._messageQueue = [];
        if (_this.onopen) {
          _this.onopen(event);
        }
        _this._listeners.open.forEach(function(listener) {
          return _this._callEventListener(event, listener);
        });
      };
      this._handleMessage = function(event) {
        _this._debug("message event");
        if (_this.onmessage) {
          _this.onmessage(event);
        }
        _this._listeners.message.forEach(function(listener) {
          return _this._callEventListener(event, listener);
        });
      };
      this._handleError = function(event) {
        _this._debug("error event", event.message);
        _this._disconnect(void 0, event.message === "TIMEOUT" ? "timeout" : void 0);
        if (_this.onerror) {
          _this.onerror(event);
        }
        _this._debug("exec error listeners");
        _this._listeners.error.forEach(function(listener) {
          return _this._callEventListener(event, listener);
        });
        _this._connect();
      };
      this._handleClose = function(event) {
        _this._debug("close event");
        _this._clearTimeouts();
        if (_this._shouldReconnect) {
          _this._connect();
        }
        if (_this.onclose) {
          _this.onclose(event);
        }
        _this._listeners.close.forEach(function(listener) {
          return _this._callEventListener(event, listener);
        });
      };
      this._url = url;
      this._protocols = protocols;
      this._options = options;
      if (this._options.startClosed) {
        this._shouldReconnect = false;
      }
      this._connect();
    }
    Object.defineProperty(ReconnectingWebSocket2, "CONNECTING", {
      get: function() {
        return 0;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket2, "OPEN", {
      get: function() {
        return 1;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket2, "CLOSING", {
      get: function() {
        return 2;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket2, "CLOSED", {
      get: function() {
        return 3;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket2.prototype, "CONNECTING", {
      get: function() {
        return ReconnectingWebSocket2.CONNECTING;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket2.prototype, "OPEN", {
      get: function() {
        return ReconnectingWebSocket2.OPEN;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket2.prototype, "CLOSING", {
      get: function() {
        return ReconnectingWebSocket2.CLOSING;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket2.prototype, "CLOSED", {
      get: function() {
        return ReconnectingWebSocket2.CLOSED;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket2.prototype, "binaryType", {
      get: function() {
        return this._ws ? this._ws.binaryType : this._binaryType;
      },
      set: function(value) {
        this._binaryType = value;
        if (this._ws) {
          this._ws.binaryType = value;
        }
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket2.prototype, "retryCount", {
      /**
       * Returns the number or connection retries
       */
      get: function() {
        return Math.max(this._retryCount, 0);
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket2.prototype, "bufferedAmount", {
      /**
       * The number of bytes of data that have been queued using calls to send() but not yet
       * transmitted to the network. This value resets to zero once all queued data has been sent.
       * This value does not reset to zero when the connection is closed; if you keep calling send(),
       * this will continue to climb. Read only
       */
      get: function() {
        var bytes = this._messageQueue.reduce(function(acc, message) {
          if (typeof message === "string") {
            acc += message.length;
          } else if (message instanceof Blob) {
            acc += message.size;
          } else {
            acc += message.byteLength;
          }
          return acc;
        }, 0);
        return bytes + (this._ws ? this._ws.bufferedAmount : 0);
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket2.prototype, "extensions", {
      /**
       * The extensions selected by the server. This is currently only the empty string or a list of
       * extensions as negotiated by the connection
       */
      get: function() {
        return this._ws ? this._ws.extensions : "";
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket2.prototype, "protocol", {
      /**
       * A string indicating the name of the sub-protocol the server selected;
       * this will be one of the strings specified in the protocols parameter when creating the
       * WebSocket object
       */
      get: function() {
        return this._ws ? this._ws.protocol : "";
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket2.prototype, "readyState", {
      /**
       * The current state of the connection; this is one of the Ready state constants
       */
      get: function() {
        if (this._ws) {
          return this._ws.readyState;
        }
        return this._options.startClosed ? ReconnectingWebSocket2.CLOSED : ReconnectingWebSocket2.CONNECTING;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(ReconnectingWebSocket2.prototype, "url", {
      /**
       * The URL as resolved by the constructor
       */
      get: function() {
        return this._ws ? this._ws.url : "";
      },
      enumerable: true,
      configurable: true
    });
    ReconnectingWebSocket2.prototype.close = function(code, reason) {
      if (code === void 0) {
        code = 1e3;
      }
      this._closeCalled = true;
      this._shouldReconnect = false;
      this._clearTimeouts();
      if (!this._ws) {
        this._debug("close enqueued: no ws instance");
        return;
      }
      if (this._ws.readyState === this.CLOSED) {
        this._debug("close: already closed");
        return;
      }
      this._ws.close(code, reason);
    };
    ReconnectingWebSocket2.prototype.reconnect = function(code, reason) {
      this._shouldReconnect = true;
      this._closeCalled = false;
      this._retryCount = -1;
      if (!this._ws || this._ws.readyState === this.CLOSED) {
        this._connect();
      } else {
        this._disconnect(code, reason);
        this._connect();
      }
    };
    ReconnectingWebSocket2.prototype.send = function(data) {
      if (this._ws && this._ws.readyState === this.OPEN) {
        this._debug("send", data);
        this._ws.send(data);
      } else {
        var _a = this._options.maxEnqueuedMessages, maxEnqueuedMessages = _a === void 0 ? DEFAULT.maxEnqueuedMessages : _a;
        if (this._messageQueue.length < maxEnqueuedMessages) {
          this._debug("enqueue", data);
          this._messageQueue.push(data);
        }
      }
    };
    ReconnectingWebSocket2.prototype.addEventListener = function(type, listener) {
      if (this._listeners[type]) {
        this._listeners[type].push(listener);
      }
    };
    ReconnectingWebSocket2.prototype.dispatchEvent = function(event) {
      var e_1, _a;
      var listeners = this._listeners[event.type];
      if (listeners) {
        try {
          for (var listeners_1 = __values(listeners), listeners_1_1 = listeners_1.next(); !listeners_1_1.done; listeners_1_1 = listeners_1.next()) {
            var listener = listeners_1_1.value;
            this._callEventListener(event, listener);
          }
        } catch (e_1_1) {
          e_1 = { error: e_1_1 };
        } finally {
          try {
            if (listeners_1_1 && !listeners_1_1.done && (_a = listeners_1.return)) _a.call(listeners_1);
          } finally {
            if (e_1) throw e_1.error;
          }
        }
      }
      return true;
    };
    ReconnectingWebSocket2.prototype.removeEventListener = function(type, listener) {
      if (this._listeners[type]) {
        this._listeners[type] = this._listeners[type].filter(function(l) {
          return l !== listener;
        });
      }
    };
    ReconnectingWebSocket2.prototype._debug = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      if (this._options.debug) {
        console.log.apply(console, __spread(["RWS>"], args));
      }
    };
    ReconnectingWebSocket2.prototype._getNextDelay = function() {
      var _a = this._options, _b = _a.reconnectionDelayGrowFactor, reconnectionDelayGrowFactor = _b === void 0 ? DEFAULT.reconnectionDelayGrowFactor : _b, _c = _a.minReconnectionDelay, minReconnectionDelay = _c === void 0 ? DEFAULT.minReconnectionDelay : _c, _d = _a.maxReconnectionDelay, maxReconnectionDelay = _d === void 0 ? DEFAULT.maxReconnectionDelay : _d;
      var delay = 0;
      if (this._retryCount > 0) {
        delay = minReconnectionDelay * Math.pow(reconnectionDelayGrowFactor, this._retryCount - 1);
        if (delay > maxReconnectionDelay) {
          delay = maxReconnectionDelay;
        }
      }
      this._debug("next delay", delay);
      return delay;
    };
    ReconnectingWebSocket2.prototype._wait = function() {
      var _this = this;
      return new Promise(function(resolve) {
        setTimeout(resolve, _this._getNextDelay());
      });
    };
    ReconnectingWebSocket2.prototype._getNextUrl = function(urlProvider) {
      if (typeof urlProvider === "string") {
        return Promise.resolve(urlProvider);
      }
      if (typeof urlProvider === "function") {
        var url = urlProvider();
        if (typeof url === "string") {
          return Promise.resolve(url);
        }
        if (!!url.then) {
          return url;
        }
      }
      throw Error("Invalid URL");
    };
    ReconnectingWebSocket2.prototype._connect = function() {
      var _this = this;
      if (this._connectLock || !this._shouldReconnect) {
        return;
      }
      this._connectLock = true;
      var _a = this._options, _b = _a.maxRetries, maxRetries = _b === void 0 ? DEFAULT.maxRetries : _b, _c = _a.connectionTimeout, connectionTimeout = _c === void 0 ? DEFAULT.connectionTimeout : _c, _d = _a.WebSocket, WebSocket2 = _d === void 0 ? getGlobalWebSocket() : _d;
      if (this._retryCount >= maxRetries) {
        this._debug("max retries reached", this._retryCount, ">=", maxRetries);
        return;
      }
      this._retryCount++;
      this._debug("connect", this._retryCount);
      this._removeListeners();
      if (!isWebSocket(WebSocket2)) {
        throw Error("No valid WebSocket class provided");
      }
      this._wait().then(function() {
        return _this._getNextUrl(_this._url);
      }).then(function(url) {
        if (_this._closeCalled) {
          return;
        }
        _this._debug("connect", { url, protocols: _this._protocols });
        _this._ws = _this._protocols ? new WebSocket2(url, _this._protocols) : new WebSocket2(url);
        _this._ws.binaryType = _this._binaryType;
        _this._connectLock = false;
        _this._addListeners();
        _this._connectTimeout = setTimeout(function() {
          return _this._handleTimeout();
        }, connectionTimeout);
      });
    };
    ReconnectingWebSocket2.prototype._handleTimeout = function() {
      this._debug("timeout event");
      this._handleError(new ErrorEvent(Error("TIMEOUT"), this));
    };
    ReconnectingWebSocket2.prototype._disconnect = function(code, reason) {
      if (code === void 0) {
        code = 1e3;
      }
      this._clearTimeouts();
      if (!this._ws) {
        return;
      }
      this._removeListeners();
      try {
        this._ws.close(code, reason);
        this._handleClose(new CloseEvent(code, reason, this));
      } catch (error) {
      }
    };
    ReconnectingWebSocket2.prototype._acceptOpen = function() {
      this._debug("accept open");
      this._retryCount = 0;
    };
    ReconnectingWebSocket2.prototype._callEventListener = function(event, listener) {
      if ("handleEvent" in listener) {
        listener.handleEvent(event);
      } else {
        listener(event);
      }
    };
    ReconnectingWebSocket2.prototype._removeListeners = function() {
      if (!this._ws) {
        return;
      }
      this._debug("removeListeners");
      this._ws.removeEventListener("open", this._handleOpen);
      this._ws.removeEventListener("close", this._handleClose);
      this._ws.removeEventListener("message", this._handleMessage);
      this._ws.removeEventListener("error", this._handleError);
    };
    ReconnectingWebSocket2.prototype._addListeners = function() {
      if (!this._ws) {
        return;
      }
      this._debug("addListeners");
      this._ws.addEventListener("open", this._handleOpen);
      this._ws.addEventListener("close", this._handleClose);
      this._ws.addEventListener("message", this._handleMessage);
      this._ws.addEventListener("error", this._handleError);
    };
    ReconnectingWebSocket2.prototype._clearTimeouts = function() {
      clearTimeout(this._connectTimeout);
      clearTimeout(this._uptimeTimeout);
    };
    return ReconnectingWebSocket2;
  }()
);
const ENV = {
  // These MUST be provided at build time via .env or environment variables
  FRONTEND_URL: "https://suna.syhc.dev",
  BACKEND_URL: "https://api.suna.syhc.dev/v1",
  IS_DEV: !chrome.runtime.getManifest().update_url
};
const getApiUrl = () => {
  const url = ENV.BACKEND_URL;
  return url.endsWith("/v1") ? url.slice(0, -3) : url;
};
const getWsUrl = () => {
  return ENV.BACKEND_URL.replace(/^http/, "ws") + "/ws/extension";
};
function getConfig() {
  return {
    apiUrl: getApiUrl(),
    wsUrl: getWsUrl(),
    frontendUrl: ENV.FRONTEND_URL
  };
}
function getConnectBrowserUrl() {
  const config = getConfig();
  return `${config.frontendUrl}/connect-browser`;
}
class KortixWebSocketClient {
  constructor() {
    __publicField(this, "ws", null);
    __publicField(this, "sessionId", null);
    __publicField(this, "heartbeatInterval", null);
    __publicField(this, "heartbeatIntervalMs", 3e4);
    __publicField(this, "state", "disconnected");
    __publicField(this, "options", null);
    __publicField(this, "extensionId", null);
  }
  /**
   * Initialize the WebSocket client
   */
  async initialize(options) {
    this.options = options;
    const stored = await chrome.storage.local.get(["extensionId", "browserToken"]);
    this.extensionId = stored.extensionId || this.generateExtensionId();
    if (!stored.extensionId) {
      await chrome.storage.local.set({ extensionId: this.extensionId });
    }
    console.log("[Kortix Extension - WS] Initialized with extension ID:", this.extensionId);
    if (stored.browserToken) {
      this.connect(stored.browserToken);
    }
  }
  /**
   * Connect to the WebSocket server
   */
  async connect(token) {
    if (this.ws) {
      this.disconnect();
    }
    const config = getConfig();
    const wsUrl = config.wsUrl;
    console.log("[Kortix Extension - WS] Connecting to:", wsUrl);
    this.setState("connecting");
    this.ws = new ReconnectingWebSocket(wsUrl, [], {
      maxReconnectionDelay: 3e4,
      minReconnectionDelay: 1e3,
      reconnectionDelayGrowFactor: 1.5,
      connectionTimeout: 1e4,
      maxRetries: Infinity
    });
    this.ws.onopen = () => {
      console.log("[Kortix Extension - WS] Connection opened, sending hello");
      this.sendHello(token);
    };
    this.ws.onmessage = (event) => {
      this.handleMessage(event.data);
    };
    this.ws.onclose = (event) => {
      console.log("[Kortix Extension - WS] Connection closed:", event.code, event.reason);
      this.setState("disconnected");
      this.stopHeartbeat();
    };
    this.ws.onerror = (error) => {
      console.error("[Kortix Extension - WS] Connection error:", error);
    };
    await chrome.storage.local.set({ browserToken: token });
  }
  /**
   * Disconnect from the server
   */
  disconnect() {
    this.stopHeartbeat();
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.sessionId = null;
    this.setState("disconnected");
    console.log("[Kortix Extension - WS] Disconnected");
  }
  /**
   * Send hello message to authenticate
   */
  sendHello(token) {
    const hello = {
      type: "hello",
      token,
      extension_id: this.extensionId,
      extension_version: chrome.runtime.getManifest().version,
      browser: navigator.userAgent,
      timestamp: Date.now()
    };
    this.send(hello);
  }
  /**
   * Handle incoming WebSocket message
   */
  handleMessage(data) {
    try {
      const message = JSON.parse(data);
      switch (message.type) {
        case "welcome":
          this.handleWelcome(message);
          break;
        case "command":
          this.handleCommand(message);
          break;
        case "heartbeat":
          console.log("[Kortix Extension - WS] Heartbeat acknowledged");
          break;
        default:
          console.warn("[Kortix Extension - WS] Unknown message type:", message.type);
      }
    } catch (error) {
      console.error("[Kortix Extension - WS] Failed to parse message:", error);
    }
  }
  /**
   * Handle welcome message (auth success)
   */
  handleWelcome(message) {
    console.log("[Kortix Extension - WS] Authenticated, session:", message.session_id);
    this.sessionId = message.session_id;
    this.heartbeatIntervalMs = message.heartbeat_interval_ms;
    this.setState("authenticated");
    this.startHeartbeat();
  }
  /**
   * Handle command from backend
   */
  async handleCommand(command) {
    console.log("[Kortix Extension - WS] Received command:", command.action, command.id);
    if (!this.options?.onCommand) {
      console.error("[Kortix Extension - WS] No command handler registered");
      return;
    }
    try {
      const result = await this.options.onCommand(command);
      this.send(result);
    } catch (error) {
      const errorResult = {
        type: "result",
        id: command.id,
        session_id: command.session_id,
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        timestamp: Date.now()
      };
      this.send(errorResult);
    }
  }
  /**
   * Start heartbeat timer
   */
  startHeartbeat() {
    this.stopHeartbeat();
    this.heartbeatInterval = setInterval(() => {
      this.sendHeartbeat();
    }, this.heartbeatIntervalMs);
  }
  /**
   * Stop heartbeat timer
   */
  stopHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
  }
  /**
   * Send heartbeat message
   */
  sendHeartbeat() {
    const heartbeat = {
      type: "heartbeat",
      timestamp: Date.now()
    };
    this.send(heartbeat);
  }
  /**
   * Send message to server
   */
  send(message) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    } else {
      console.warn("[Kortix Extension - WS] Cannot send, WebSocket not open");
    }
  }
  /**
   * Send an encoded video frame to the backend.
   * Uses base64 for now to maintain compatibility with JSON protocol,
   * but much more efficient than full screenshots.
   */
  sendVideoFrame(data, isKeyFrame, timestamp) {
    if (!this.isConnected || !this.ws) return;
    const bytes = new Uint8Array(data);
    let binary = "";
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const base64 = btoa(binary);
    const message = {
      type: "video_frame",
      browser_id: this.sessionId || "unknown",
      data: base64,
      is_keyframe: isKeyFrame,
      timestamp
    };
    this.send(message);
  }
  /**
   * Update connection state
   */
  setState(state2) {
    if (this.state !== state2) {
      this.state = state2;
      this.options?.onStateChange?.(state2);
      console.log("[Kortix Extension - WS] State changed:", state2);
    }
  }
  /**
   * Generate unique extension ID
   */
  generateExtensionId() {
    return `ext_${Date.now().toString(36)}_${Math.random().toString(36).substr(2, 9)}`;
  }
  // ========== Public Getters ==========
  get isConnected() {
    return this.state === "authenticated";
  }
  get currentState() {
    return this.state;
  }
  get currentSessionId() {
    return this.sessionId;
  }
  get currentExtensionId() {
    return this.extensionId;
  }
}
const wsClient = new KortixWebSocketClient();
class DebuggerCapture {
  constructor() {
    __publicField(this, "attachedTabs", /* @__PURE__ */ new Set());
  }
  /**
   * Capture screenshot of a specific tab without activating it.
   * Uses CDP Page.captureScreenshot command.
   * 
   * @param tabId - The tab ID to capture
   * @param format - Image format: 'png', 'jpeg', or 'webp'
   * @returns Base64 encoded screenshot data (no data URL prefix)
   */
  async captureTab(tabId, format = "png") {
    const debuggee = { tabId };
    if (!this.attachedTabs.has(tabId)) {
      await this.attach(tabId);
    }
    try {
      console.log(`[DebuggerCapture] Sending Page.captureScreenshot for tab ${tabId}...`);
      const result = await new Promise((resolve, reject) => {
        chrome.debugger.sendCommand(
          debuggee,
          "Page.captureScreenshot",
          {
            format,
            quality: format === "jpeg" ? 80 : void 0
          },
          (response) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else {
              resolve(response);
            }
          }
        );
      });
      if (!result || !result.data) {
        console.warn(`[DebuggerCapture] Received empty screenshot data for tab ${tabId}`);
        throw new Error("Empty screenshot data");
      }
      console.log(`[DebuggerCapture] Successfully captured screenshot for tab ${tabId} (${result.data.length} bytes)`);
      return result.data;
    } catch (error) {
      console.error(`[DebuggerCapture] Failed to capture tab ${tabId}:`, error);
      throw error;
    }
  }
  /**
   * Attach debugger to a tab (persistent for streaming session).
   * Multiple calls with the same tabId are idempotent.
   */
  async attach(tabId) {
    if (this.attachedTabs.has(tabId)) {
      console.log(`[DebuggerCapture] Already attached to tab ${tabId}`);
      return;
    }
    return new Promise((resolve, reject) => {
      chrome.debugger.attach({ tabId }, "1.3", () => {
        if (chrome.runtime.lastError) {
          if (chrome.runtime.lastError.message?.includes("already attached")) {
            this.attachedTabs.add(tabId);
            console.log(`[DebuggerCapture] Tab ${tabId} was already attached`);
            resolve();
          } else {
            reject(new Error(chrome.runtime.lastError.message));
          }
        } else {
          this.attachedTabs.add(tabId);
          console.log(`[DebuggerCapture] Attached to tab ${tabId}`);
          chrome.debugger.sendCommand({ tabId }, "Page.enable", {}, () => {
            resolve();
          });
        }
      });
    });
  }
  /**
   * Detach debugger from a tab.
   */
  async detach(tabId) {
    if (!this.attachedTabs.has(tabId)) {
      return;
    }
    return new Promise((resolve) => {
      chrome.debugger.detach({ tabId }, () => {
        this.attachedTabs.delete(tabId);
        console.log(`[DebuggerCapture] Detached from tab ${tabId}`);
        resolve();
      });
    });
  }
  /**
   * Detach from all tabs.
   */
  async detachAll() {
    const detachPromises = Array.from(this.attachedTabs).map((tabId) => this.detach(tabId));
    await Promise.all(detachPromises);
  }
  /**
   * Check if debugger is attached to a tab.
   */
  isAttached(tabId) {
    return this.attachedTabs.has(tabId);
  }
  /**
   * Get all attached tab IDs.
   */
  get attachedTabIds() {
    return Array.from(this.attachedTabs);
  }
}
const debuggerCapture = new DebuggerCapture();
class KortixTabGroupManager {
  constructor() {
    __publicField(this, "groupId", null);
    __publicField(this, "windowId", null);
    __publicField(this, "activeTabId", null);
    __publicField(this, "tabIds", /* @__PURE__ */ new Set());
  }
  /**
   * Get or create a dedicated window for Kortix.
   * Dimensions fixed to 1440x900 for consistency with Sandbox.
   */
  async getOrCreateWindow() {
    if (this.windowId !== null) {
      try {
        const win2 = await chrome.windows.get(this.windowId);
        return win2.id;
      } catch (e) {
        this.windowId = null;
      }
    }
    if (this.groupId !== null) {
      try {
        const group = await chrome.tabGroups.get(this.groupId);
        this.windowId = group.windowId;
        return this.windowId;
      } catch (e) {
        this.groupId = null;
      }
    }
    const existingGroups = await chrome.tabGroups.query({ title: "Kortix" });
    if (existingGroups.length > 0) {
      this.windowId = existingGroups[0].windowId;
      this.groupId = existingGroups[0].id;
      return this.windowId;
    }
    const width = 1440;
    const height = 900;
    const win = await chrome.windows.create({
      focused: true,
      // Focus once on create so user sees it
      type: "normal",
      width,
      height
    });
    this.windowId = win.id;
    console.log(`[Kortix Extension - Tabs] Created dedicated window (${width}x${height}):`, this.windowId);
    return this.windowId;
  }
  /**
   * Get or create the Kortix tab group
   */
  async getOrCreateGroup() {
    const windowId = await this.getOrCreateWindow();
    let group = null;
    if (this.groupId !== null) {
      try {
        const existing = await chrome.tabGroups.get(this.groupId);
        if (existing.title === "Kortix") {
          group = existing;
          if (group.windowId !== windowId) {
            console.log("[Kortix Extension - Tabs] Moving group to dedicated window");
            const tabs = await chrome.tabs.query({ groupId: group.id });
            await chrome.tabs.move(tabs.map((t) => t.id), { windowId, index: -1 });
          }
        }
      } catch (e) {
        this.groupId = null;
      }
    }
    if (!group) {
      const existingGroups = await chrome.tabGroups.query({ title: "Kortix" });
      if (existingGroups.length > 0) {
        group = existingGroups[0];
        this.groupId = group.id;
        if (group.windowId !== windowId) {
          const tabs = await chrome.tabs.query({ groupId: group.id });
          await chrome.tabs.move(tabs.map((t) => t.id), { windowId, index: -1 });
        }
      }
    }
    if (group) {
      const tabs = await chrome.tabs.query({ groupId: group.id });
      this.tabIds = new Set(tabs.map((t) => t.id));
      this.enforceGroupVisuals(group.id);
      return group.id;
    }
    const tab = await chrome.tabs.create({
      windowId,
      url: "https://www.google.com",
      active: false
    });
    if (!tab.id) throw new Error("Failed to create tab");
    await new Promise((resolve) => setTimeout(resolve, 100));
    this.groupId = await chrome.tabs.group({ tabIds: [tab.id] });
    console.log("[Kortix Extension - Tabs] Grouped tab into new group:", this.groupId);
    await new Promise((resolve) => setTimeout(resolve, 50));
    this.enforceGroupVisuals(this.groupId);
    this.tabIds.add(tab.id);
    this.activeTabId = tab.id;
    return this.groupId;
  }
  /**
   * Enforce group color and title with retries (Comet/Edge/AI-organizer safety)
   */
  async enforceGroupVisuals(groupId, retries = 3) {
    const apply = async () => {
      try {
        await chrome.tabGroups.update(groupId, {
          title: "Kortix",
          color: "purple",
          collapsed: false
        });
        const updated = await chrome.tabGroups.get(groupId);
        console.log(`[Kortix Extension - Tabs] Group ${groupId} visuals: title="${updated.title}", color="${updated.color}"`);
        if (updated.color !== "purple" && retries > 0) {
          console.warn(`[Kortix Extension - Tabs] Color mismatch in Comet/Browser (expected purple, got ${updated.color}). Retrying...`);
          setTimeout(() => this.enforceGroupVisuals(groupId, retries - 1), 500);
        }
      } catch (e) {
        console.error("[Kortix Extension - Tabs] Failed to update group visuals:", e);
      }
    };
    apply();
  }
  /**
   * Create a new tab in the Kortix group
   */
  async createTab(url, activate = true) {
    const groupId = await this.getOrCreateGroup();
    const tab = await chrome.tabs.create({ url, active: activate });
    if (!tab.id) throw new Error("Failed to create tab");
    await chrome.tabs.group({ tabIds: [tab.id], groupId });
    this.tabIds.add(tab.id);
    if (activate) {
      this.activeTabId = tab.id;
    }
    console.log("[Kortix Extension - Tabs] Created tab:", tab.id, url);
    return tab;
  }
  /**
   * Navigate the current active tab, or create a new one if needed
   */
  async navigate(url) {
    if (this.activeTabId !== null) {
      try {
        const tab = await chrome.tabs.get(this.activeTabId);
        if (tab.groupId === this.groupId) {
          await chrome.tabs.update(this.activeTabId, { url, active: true });
          console.log("[Kortix Extension - Tabs] Navigated existing tab:", this.activeTabId, url);
          return tab;
        }
      } catch (e) {
      }
    }
    return this.createTab(url, true);
  }
  /**
   * Get the current active tab in the Kortix group
   */
  async getActiveTab() {
    if (this.activeTabId !== null) {
      try {
        const tab = await chrome.tabs.get(this.activeTabId);
        if (tab.groupId === this.groupId) {
          return tab;
        }
      } catch (e) {
        this.activeTabId = null;
      }
    }
    if (this.groupId !== null) {
      try {
        const tabs = await chrome.tabs.query({ groupId: this.groupId });
        if (tabs.length > 0) {
          this.activeTabId = tabs[0].id;
          return tabs[0];
        }
      } catch (e) {
        console.error("[Kortix Extension - Tabs] Failed to query tabs in group:", e);
      }
    }
    return null;
  }
  /**
   * Switch to a specific tab in the group
   */
  async switchTab(tabId) {
    if (this.tabIds.has(tabId)) {
      await chrome.tabs.update(tabId, { active: true });
      this.activeTabId = tabId;
      console.log("[Kortix Extension - Tabs] Switched to tab:", tabId);
    } else {
      const tabs = await this.getGroupTabs();
      const tab = tabs.find((t) => t.id === tabId);
      if (tab) {
        await chrome.tabs.update(tabId, { active: true });
        this.activeTabId = tabId;
        this.tabIds.add(tabId);
      } else {
        throw new Error(`Tab ${tabId} not found in Kortix group`);
      }
    }
  }
  /**
   * Close the current active tab
   */
  async closeActiveTab() {
    if (this.activeTabId === null) return;
    try {
      await chrome.tabs.remove(this.activeTabId);
      this.tabIds.delete(this.activeTabId);
      console.log("[Kortix Extension - Tabs] Closed tab:", this.activeTabId);
      const tabs = await this.getGroupTabs();
      if (tabs.length > 0) {
        this.activeTabId = tabs[0].id;
      } else {
        this.activeTabId = null;
      }
    } catch (e) {
    }
  }
  /**
   * Get all tabs in the Kortix group
   */
  async getGroupTabs() {
    if (this.groupId === null) return [];
    return chrome.tabs.query({ groupId: this.groupId });
  }
  /**
   * Capture screenshot of a tab.
   * 
   * REFACTORED: Now uses chrome.debugger + Page.captureScreenshot
   * which does NOT require the tab to be active/visible.
   * This fixes the annoying tab-switching bug.
   * 
   * @param tabId - Optional specific tab ID. If not provided, uses active tab.
   */
  /**
   * Capture screenshot of a tab.
   * 
   * @param tabId - Optional specific tab ID. If not provided, uses active tab.
   * @param clean - If true, hides the overlay before capture to get a clean shot.
   */
  async captureScreenshot(tabId, clean = true) {
    let targetTabId = tabId;
    if (!targetTabId) {
      const tab = await this.getActiveTab();
      if (!tab?.id) {
        await this.getOrCreateGroup();
        const newTab = await this.getActiveTab();
        if (!newTab?.id) throw new Error("No active tab to capture");
        targetTabId = newTab.id;
      } else {
        targetTabId = tab.id;
      }
    }
    try {
      if (clean) {
        await chrome.tabs.sendMessage(targetTabId, {
          type: "SET_OVERLAY_VISIBILITY",
          visible: false
        }).catch(() => {
        });
      }
      const base64 = await debuggerCapture.captureTab(targetTabId, "png");
      if (clean) {
        await chrome.tabs.sendMessage(targetTabId, {
          type: "SET_OVERLAY_VISIBILITY",
          visible: true
        }).catch(() => {
        });
      }
      if (!base64) throw new Error("Capture returned empty result");
      return base64;
    } catch (e) {
      const errorMsg = e instanceof Error ? e.message : String(e);
      console.error(`[Kortix Extension - Tabs] Failed to capture screenshot:`, e);
      throw new Error(`Screenshot failed: ${errorMsg}`);
    }
  }
  /**
   * Execute a function in the active tab's content script
   */
  async executeInActiveTab(func) {
    const tab = await this.getActiveTab();
    if (!tab || !tab.id) {
      throw new Error("No active tab");
    }
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func
    });
    if (results.length === 0) {
      throw new Error("Script execution returned no results");
    }
    return results[0].result;
  }
  /**
   * Send a message to the content script in the active tab
   */
  async sendToActiveTab(message) {
    const tab = await this.getActiveTab();
    if (!tab || !tab.id) {
      throw new Error("No active tab");
    }
    return chrome.tabs.sendMessage(tab.id, message);
  }
  /**
   * Collapse or expand the tab group
   */
  async setCollapsed(collapsed) {
    if (this.groupId === null) return;
    await chrome.tabGroups.update(this.groupId, { collapsed });
  }
  /**
   * Clean up all tabs in the group and close the dedicated window
   */
  async cleanup() {
    if (this.windowId !== null) {
      try {
        await chrome.windows.remove(this.windowId);
      } catch (e) {
      }
    }
    this.tabIds.clear();
    this.activeTabId = null;
    this.groupId = null;
    this.windowId = null;
    console.log("[Kortix Extension - Tabs] Cleaned up and closed window");
  }
  // ========== State ==========
  get state() {
    return {
      groupId: this.groupId,
      windowId: this.windowId,
      activeTabId: this.activeTabId,
      tabIds: Array.from(this.tabIds)
    };
  }
}
const tabGroupManager = new KortixTabGroupManager();
class InputManager {
  constructor() {
    __publicField(this, "attachedTabs", /* @__PURE__ */ new Set());
  }
  /**
   * Attach debugger to a tab if not already attached
   */
  async ensureAttached(tabId) {
    if (this.attachedTabs.has(tabId)) return;
    return new Promise((resolve, reject) => {
      chrome.debugger.attach({ tabId }, "1.3", () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          this.attachedTabs.add(tabId);
          chrome.debugger.sendCommand({ tabId }, "Input.enable", {}, () => {
            resolve();
          });
        }
      });
    });
  }
  /**
   * Dispatch a mouse event
   */
  async dispatchMouseEvent(tabId, params) {
    await this.ensureAttached(tabId);
    return new Promise((resolve, reject) => {
      chrome.debugger.sendCommand({ tabId }, "Input.dispatchMouseEvent", params, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });
  }
  /**
   * Dispatch a keyboard event
   */
  async dispatchKeyEvent(tabId, params) {
    await this.ensureAttached(tabId);
    return new Promise((resolve, reject) => {
      chrome.debugger.sendCommand({ tabId }, "Input.dispatchKeyEvent", params, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });
  }
  /**
   * Detach from a tab
   */
  async detach(tabId) {
    if (!this.attachedTabs.has(tabId)) return;
    return new Promise((resolve) => {
      chrome.debugger.detach({ tabId }, () => {
        this.attachedTabs.delete(tabId);
        resolve();
      });
    });
  }
  /**
   * Detach from all tabs
   */
  async detachAll() {
    const detachPromises = Array.from(this.attachedTabs).map((tabId) => this.detach(tabId));
    await Promise.all(detachPromises);
  }
}
const inputManager = new InputManager();
class StreamingManager {
  constructor() {
    __publicField(this, "isStreaming", false);
    __publicField(this, "streamInterval", null);
    __publicField(this, "targetFps", 10);
    __publicField(this, "lastFrameHash", null);
    __publicField(this, "targetTabId", null);
    __publicField(this, "isVideoStreamingStarted", false);
    __publicField(this, "lastUpdateTimestamp", 0);
  }
  /**
   * Start streaming a specific tab (or default to first tab in Kortix group).
   * The tab does NOT need to be active - we can stream background tabs.
   * 
   * @param tabId - Optional specific tab ID to stream. If not provided,
   *                uses the first tab in the Kortix group.
   */
  async start(tabId) {
    if (this.isStreaming) {
      console.log("[Kortix Extension - Stream] Already streaming");
      return;
    }
    if (tabId) {
      this.targetTabId = tabId;
    } else {
      const groupTabs = await tabGroupManager.getGroupTabs();
      if (groupTabs.length > 0) {
        this.targetTabId = groupTabs[0].id;
      } else {
        await tabGroupManager.getOrCreateGroup();
        const tab = await tabGroupManager.getActiveTab();
        if (tab?.id) {
          this.targetTabId = tab.id;
        }
      }
    }
    if (!this.targetTabId) {
      console.error("[Kortix Extension - Stream] No target tab to stream");
      return;
    }
    try {
      await debuggerCapture.attach(this.targetTabId);
    } catch (error) {
      console.error("[Kortix Extension - Stream] Failed to attach debugger:", error);
    }
    this.isStreaming = true;
    this.lastFrameHash = null;
    console.log(`[Kortix Extension - Stream] Starting stream for tab ${this.targetTabId}...`);
    await this.ensureOffscreenDocument();
    this.captureLoop();
  }
  /**
   * Ensure the offscreen document is created for video processing
   */
  async ensureOffscreenDocument() {
    if (await chrome.offscreen.hasDocument()) {
      return;
    }
    console.log("[Kortix Extension - Stream] Creating offscreen document...");
    await chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: [chrome.offscreen.Reason.USER_MEDIA, chrome.offscreen.Reason.DISPLAY_MEDIA],
      justification: "Recording tab for high-performance video streaming to Kortix Worker."
    });
  }
  /**
   * Initialize the high-performance video pipeline
   */
  async initializeVideoStreaming() {
    if (this.isVideoStreamingStarted || !this.targetTabId) return;
    this.isVideoStreamingStarted = true;
    try {
      console.log("[Kortix Extension - Stream] Initializing video pipeline...");
      const tab = await chrome.tabs.get(this.targetTabId);
      const streamId = await new Promise((resolve, reject) => {
        chrome.tabCapture.getMediaStreamId({
          targetTabId: this.targetTabId
        }, (streamId2) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(streamId2);
          }
        });
      });
      await chrome.runtime.sendMessage({
        type: "START_STREAMING",
        streamId,
        tabId: this.targetTabId,
        url: tab.url,
        title: tab.title
      });
      console.log("[Kortix Extension - Stream] Video pipeline initialized in offscreen document");
    } catch (error) {
      console.error("[Kortix Extension - Stream] Failed to initialize video pipeline:", error);
      this.isVideoStreamingStarted = false;
    }
  }
  /**
   * Recursive capture loop for stable FPS and frame synchronization
   * This is a LEGACY fallback path. It will automatically pause if the 
   * high-performance video pipeline is active to prevent 'strobe' flickering.
   */
  async captureLoop() {
    if (!this.isStreaming) return;
    if (this.isVideoStreamingStarted) {
      this.streamInterval = setTimeout(() => this.captureLoop(), 2e3);
      return;
    }
    const startTime = Date.now();
    await this.captureAndPush();
    if (this.isVideoStreamingStarted && Date.now() - this.lastUpdateTimestamp > 5e3) {
      this.updateVideoMetadata().catch(() => {
      });
      this.lastUpdateTimestamp = Date.now();
    }
    const duration = Date.now() - startTime;
    const intervalMs = 1e3 / this.targetFps;
    const nextDelay = Math.max(0, intervalMs - duration);
    this.streamInterval = setTimeout(() => this.captureLoop(), nextDelay);
  }
  async updateVideoMetadata() {
    if (!this.targetTabId || !this.isVideoStreamingStarted) return;
    try {
      const tab = await chrome.tabs.get(this.targetTabId);
      await chrome.runtime.sendMessage({
        type: "UPDATE_METADATA",
        url: tab.url,
        title: tab.title
      });
    } catch (e) {
    }
  }
  /**
   * Switch streaming to a different tab.
   */
  async switchTab(tabId) {
    console.log(`[Kortix Extension - Stream] Switching from tab ${this.targetTabId} to ${tabId}`);
    if (this.targetTabId && this.targetTabId !== tabId) {
      await debuggerCapture.detach(this.targetTabId);
    }
    this.targetTabId = tabId;
    this.lastFrameHash = null;
    await debuggerCapture.attach(tabId);
    console.log(`[Kortix Extension - Stream] Now streaming tab ${tabId}`);
  }
  /**
   * Stop streaming and clean up.
   */
  stop() {
    this.isStreaming = false;
    this.isVideoStreamingStarted = false;
    if (this.streamInterval) {
      clearTimeout(this.streamInterval);
      this.streamInterval = null;
    }
    chrome.offscreen.closeDocument().catch(() => {
    });
    if (this.targetTabId) {
      debuggerCapture.detach(this.targetTabId).catch(console.error);
      this.targetTabId = null;
    }
    this.lastFrameHash = null;
    console.log("[Kortix Extension - Stream] Stream stopped");
  }
  /**
   * Set the target FPS for streaming.
   */
  setFps(fps) {
    this.targetFps = Math.max(1, Math.min(30, fps));
  }
  /**
   * Capture screenshot and push to backend via WebSocket.
   */
  async captureAndPush() {
    if (!wsClient.isConnected || !this.targetTabId) return;
    this.initializeVideoStreaming().catch(console.error);
    try {
      let tab;
      try {
        tab = await chrome.tabs.get(this.targetTabId);
      } catch (e) {
        console.warn("[Kortix Extension - Stream] Target tab was closed");
        this.stop();
        return;
      }
      const screenshotBase64 = await debuggerCapture.captureTab(this.targetTabId, "png");
      if (!screenshotBase64) return;
      const frameHash = screenshotBase64.substring(0, 100);
      if (frameHash === this.lastFrameHash) {
        return;
      }
      this.lastFrameHash = frameHash;
      const message = {
        type: "stream_chunk",
        browser_id: wsClient.currentSessionId || "unknown",
        screenshot_base64: screenshotBase64,
        url: tab.url || "",
        title: tab.title || "",
        timestamp: Date.now()
      };
      wsClient.send(message);
    } catch (error) {
      if (this.isStreaming) {
        console.error("[Kortix Extension - Stream] Capture error:", error);
      }
    }
  }
  // ========== Getters ==========
  /**
   * Get the currently streaming tab ID.
   */
  get currentTargetTabId() {
    return this.targetTabId;
  }
  /**
   * Check if currently streaming.
   */
  get streaming() {
    return this.isStreaming;
  }
  /**
   * Get current FPS setting.
   */
  get fps() {
    return this.targetFps;
  }
  /**
   * Helper to toggle overlay visibility via messaging
   */
  async setOverlayVisibility(visible) {
    if (!this.targetTabId) return;
    try {
      await chrome.tabs.sendMessage(this.targetTabId, {
        type: "SET_OVERLAY_VISIBILITY",
        visible
      });
    } catch (e) {
    }
  }
}
const streamingManager = new StreamingManager();
let state = {
  isConnected: false,
  sessionId: null,
  extensionId: null,
  commandCount: 0
};
async function handleBackendCommand(command) {
  console.log(
    "[Kortix Extension - Background] Handling command:",
    command.action
  );
  state.commandCount++;
  try {
    await tabGroupManager.getOrCreateGroup();
    if (!streamingManager.streaming) {
      await streamingManager.start();
      setOverlayState(true);
    }
    let data = {};
    switch (command.action) {
      case "navigate":
        await handleNavigate(command.params);
        data = await getPageState();
        break;
      case "click":
        await handleClick(command.params);
        data = await getPageState();
        break;
      case "type":
        await handleType(command.params);
        data = await getPageState();
        break;
      case "scroll_down":
        await handleScroll({ direction: "down" });
        data = await getPageState();
        break;
      case "scroll_up":
        await handleScroll({ direction: "up" });
        data = await getPageState();
        break;
      case "screenshot":
        const screenshot = await tabGroupManager.captureScreenshot();
        const tab = await tabGroupManager.getActiveTab();
        data = {
          screenshot_base64: screenshot,
          url: tab?.url || "",
          title: tab?.title || ""
        };
        break;
      case "new_tab":
        await tabGroupManager.createTab(command.params.url || "");
        data = await getPageState();
        break;
      case "close_tab":
        await tabGroupManager.closeActiveTab();
        data = await getPageState();
        break;
      case "switch_tab":
        const tabId = command.params.tabId || command.params.tab_id;
        if (!tabId) throw new Error("Missing tabId parameter");
        await tabGroupManager.switchTab(Number(tabId));
        data = await getPageState();
        break;
      case "interaction":
        await handleInteraction(command);
        return {
          type: "result",
          id: command.id,
          session_id: command.session_id,
          success: true,
          timestamp: Date.now()
        };
      default:
        throw new Error(`Unknown action: ${command.action}`);
    }
    return {
      type: "result",
      id: command.id,
      session_id: command.session_id,
      success: true,
      data,
      timestamp: Date.now()
    };
  } catch (error) {
    console.error("[Kortix Extension - Background] Command error:", error);
    return {
      type: "result",
      id: command.id,
      session_id: command.session_id,
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
      timestamp: Date.now()
    };
  }
}
async function handleNavigate(params) {
  const { url } = params;
  if (!url) throw new Error("Missing url parameter");
  await tabGroupManager.navigate(url);
  await new Promise((resolve) => setTimeout(resolve, 1e3));
}
async function handleClick(params) {
  const { selector, x, y } = params;
  if (selector) {
    await tabGroupManager.sendToActiveTab({
      type: "executeCommand",
      command: { action: "click", params: { selector } }
    });
  } else if (x !== void 0 && y !== void 0) {
    await tabGroupManager.executeInActiveTab(() => {
      const element = document.elementFromPoint(x, y);
      if (element instanceof HTMLElement) {
        element.click();
      }
    });
  } else {
    throw new Error("Missing selector or coordinates");
  }
}
async function handleType(params) {
  const { selector, text, clear = true } = params;
  if (!selector) throw new Error("Missing selector parameter");
  if (!text) throw new Error("Missing text parameter");
  await tabGroupManager.sendToActiveTab({
    type: "executeCommand",
    command: { action: "type", params: { selector, text, clear } }
  });
}
async function handleInteraction(command) {
  const { action, params } = command;
  const tab = await tabGroupManager.getActiveTab();
  if (!tab || !tab.id) return;
  switch (params.type) {
    case "click":
      await inputManager.dispatchMouseEvent(tab.id, {
        type: "mousePressed",
        x: params.x,
        y: params.y,
        button: params.button || "left",
        clickCount: 1
      });
      await inputManager.dispatchMouseEvent(tab.id, {
        type: "mouseReleased",
        x: params.x,
        y: params.y,
        button: params.button || "left",
        clickCount: 1
      });
      break;
    case "mouse_move":
      await inputManager.dispatchMouseEvent(tab.id, {
        type: "mouseMoved",
        x: params.x,
        y: params.y
      });
      break;
    case "key_down":
      await inputManager.dispatchKeyEvent(tab.id, {
        type: "keyDown",
        text: params.key,
        unmodifiedText: params.key,
        key: params.key
      });
      break;
    case "key_up":
      await inputManager.dispatchKeyEvent(tab.id, {
        type: "keyUp",
        key: params.key
      });
      break;
    case "scroll":
      await inputManager.dispatchMouseEvent(tab.id, {
        type: "mouseWheel",
        x: 0,
        y: 0,
        deltaX: params.deltaX || 0,
        deltaY: params.deltaY || 0
      });
      break;
  }
}
async function handleScroll(params) {
  const { direction, amount = 500 } = params;
  await tabGroupManager.sendToActiveTab({
    type: "executeCommand",
    command: { action: "scroll", params: { direction, amount } }
  });
  await new Promise((resolve) => setTimeout(resolve, 300));
}
async function getPageState() {
  const tab = await tabGroupManager.getActiveTab();
  const screenshot = await tabGroupManager.captureScreenshot(void 0, false);
  return {
    url: tab?.url || "",
    title: tab?.title || "",
    screenshot_base64: screenshot
  };
}
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const { type } = request;
  if (type === "getStatus") {
    sendResponse({
      isConnected: wsClient.isConnected,
      state: wsClient.currentState,
      sessionId: wsClient.currentSessionId,
      extensionId: wsClient.currentExtensionId,
      commandCount: state.commandCount,
      tabGroup: tabGroupManager.state
    });
    return true;
  }
  if (type === "connect") {
    const { token } = request;
    if (token) {
      wsClient.connect(token).then(() => {
        sendResponse({ success: true });
      }).catch((error) => {
        sendResponse({ success: false, error: error.message });
      });
    } else {
      sendResponse({ success: false, error: "No token provided" });
    }
    return true;
  }
  if (type === "disconnect") {
    wsClient.disconnect();
    sendResponse({ success: true });
    return true;
  }
  if (type === "openLoginPage") {
    chrome.tabs.create({ url: getConnectBrowserUrl() });
    sendResponse({ success: true });
    return true;
  }
  if (type === "executeCommand") {
    const { command, commandId } = request;
    handleLegacyCommand(command, commandId).then((result) => sendResponse(result)).catch(
      (error) => sendResponse({
        commandId,
        success: false,
        error: error.message,
        timestamp: Date.now()
      })
    );
    return true;
  }
  sendResponse({ success: false, error: "Unknown message type" });
  return true;
});
async function handleLegacyCommand(command, commandId) {
  const backendCommand = {
    type: "command",
    id: commandId,
    session_id: "local",
    action: command.action,
    params: command.params || {},
    timeout_ms: 3e4,
    timestamp: Date.now()
  };
  const result = await handleBackendCommand(backendCommand);
  return {
    commandId,
    success: result.success,
    data: result.data,
    error: result.error,
    timestamp: result.timestamp
  };
}
async function setOverlayState(visible) {
  const groupState = tabGroupManager.state;
  if (!groupState.windowId) return;
  try {
    const tabs = await chrome.tabs.query({ windowId: groupState.windowId });
    const promises = tabs.map((tab) => {
      if (tab.id) {
        return chrome.tabs.sendMessage(tab.id, {
          type: "SET_OVERLAY_STATE",
          visible
        }).catch(() => {
        });
      }
    });
    await Promise.all(promises);
  } catch (e) {
    console.error(
      "[Kortix Extension - Background] Failed to set overlay state:",
      e
    );
  }
}
async function initialize() {
  console.log("[Kortix Extension - Background] Initializing extension...");
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "USER_TAKEOVER") {
      console.log(
        "[Kortix Extension - Background] Takeover requested by user (Pausing stream)"
      );
      streamingManager.stop();
      if (wsClient.isConnected) {
        wsClient.send({
          type: "user_takeover",
          session_id: wsClient.currentSessionId || "unknown",
          timestamp: Date.now()
        });
      }
    }
    if (message.type === "RESUME_TASK") {
      console.log("[Kortix Extension - Background] Resume requested by user");
      const { summary } = message;
      streamingManager.start().then(() => {
        setOverlayState(true);
      }).catch(console.error);
      if (wsClient.isConnected) {
        wsClient.send({
          type: "user_resume",
          session_id: wsClient.currentSessionId || "unknown",
          summary: summary || "",
          timestamp: Date.now()
        });
      }
      console.log(
        "[Kortix Extension - Background] Sent resume with summary:",
        summary
      );
    }
    if (message.type === "VIDEO_CHUNK") {
      const { data, isKeyFrame, timestamp } = message;
      wsClient.sendVideoFrame(data, isKeyFrame, timestamp);
    }
  });
  await wsClient.initialize({
    onCommand: handleBackendCommand,
    onStateChange: (connectionState) => {
      state.isConnected = connectionState === "authenticated";
      state.sessionId = wsClient.currentSessionId;
      state.extensionId = wsClient.currentExtensionId;
      console.log(
        "[Kortix Extension - Background] Connection state:",
        connectionState
      );
      if (!state.isConnected) {
        streamingManager.stop();
        setOverlayState(false);
      }
    }
  });
  console.log("[Kortix Extension - Background] Extension initialized");
}
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log("[Kortix Extension - Background] onInstalled event:", details);
  const isDev = !chrome.runtime.getManifest().update_url;
  const shouldOpen = details.reason === "install" || isDev && details.reason === "update";
  if (shouldOpen) {
    console.log(
      "[Kortix Extension - Background] Opening connect page (Reason: " + details.reason + ")"
    );
    const url = getConnectBrowserUrl();
    console.log("[Kortix Extension - Background] Connect URL:", url);
    chrome.tabs.create({ url });
  }
  if (details.reason === "update") {
    console.log(
      "[Kortix Extension - Background] Extension updated to version",
      chrome.runtime.getManifest().version
    );
  }
});
chrome.runtime.onStartup.addListener(() => {
  console.log(
    "[Kortix Extension - Background] Browser started, reinitializing..."
  );
  initialize().catch(console.error);
});
initialize().catch(console.error);
