console.log("[Kortix Offscreen] Document loaded");
let encoder = null;
let stream = null;
let reader = null;
let frameCount = 0;
let currentUrl = "";
let currentTitle = "";
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "START_STREAMING") {
    console.log("[Kortix Offscreen] Starting stream with ID:", message.streamId);
    currentUrl = message.url || "";
    currentTitle = message.title || "";
    startCapture(message.streamId);
    sendResponse({ success: true });
  }
  if (message.type === "UPDATE_METADATA") {
    currentUrl = message.url || currentUrl;
    currentTitle = message.title || currentTitle;
    sendResponse({ success: true });
  }
  if (message.type === "STOP_STREAMING") {
    stopCapture();
    sendResponse({ success: true });
  }
  return true;
});
async function startCapture(streamId) {
  try {
    stopCapture();
    stream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: {
        mandatory: {
          chromeMediaSource: "tab",
          chromeMediaSourceId: streamId,
          maxWidth: 1280,
          maxHeight: 720,
          maxFrameRate: 30
        }
      }
    });
    const videoTrack = stream.getVideoTracks()[0];
    console.log("[Kortix Offscreen] MediaStream obtained:", videoTrack.label);
    setupEncoder();
    const processor = new window.MediaStreamTrackProcessor({ track: videoTrack });
    reader = processor.readable.getReader();
    readFrames();
  } catch (error) {
    console.error("[Kortix Offscreen] Failed to start capture:", error);
  }
}
function setupEncoder() {
  encoder = new VideoEncoder({
    output: (chunk, metadata) => {
      handleEncodedChunk(chunk, metadata);
    },
    error: (e) => {
      console.error("[Kortix Offscreen] VideoEncoder error:", e);
    }
  });
  const config = {
    codec: "avc1.42E01E",
    // Baseline profile for low latency
    width: 1280,
    // Default target width
    height: 720,
    // Default target height
    bitrate: 2e6,
    // 2 Mbps
    framerate: 30,
    latencyMode: "realtime",
    avc: { format: "annexb" }
    // Use Annex B for easier relaying to MediaSource
  };
  encoder.configure(config);
}
async function readFrames() {
  if (!reader || !encoder) return;
  try {
    while (true) {
      const { done, value: frame } = await reader.read();
      if (done) break;
      if (encoder.encodeQueueSize > 5) {
        frame.close();
        continue;
      }
      const keyFrame = frameCount % 60 === 0;
      encoder.encode(frame, { keyFrame });
      frame.close();
      frameCount++;
    }
  } catch (e) {
    console.error("[Kortix Offscreen] Error reading frames:", e);
  }
}
function handleEncodedChunk(chunk, metadata) {
  const buffer = new Uint8Array(chunk.byteLength);
  chunk.copyTo(buffer);
  const message = {
    type: "VIDEO_CHUNK",
    data: buffer.buffer,
    // Send ArrayBuffer
    isKeyFrame: chunk.type === "key",
    timestamp: chunk.timestamp,
    metadata
  };
  if (chunk.type === "key" && stream) {
    const videoTrack = stream.getVideoTracks()[0];
    if (videoTrack) {
      message.url = currentUrl;
      message.title = currentTitle;
    }
  }
  chrome.runtime.sendMessage(message);
}
function stopCapture() {
  if (reader) {
    reader.cancel();
    reader = null;
  }
  if (stream) {
    stream.getTracks().forEach((track) => track.stop());
    stream = null;
  }
  if (encoder) {
    if (encoder.state !== "closed") {
      encoder.close();
    }
    encoder = null;
  }
  frameCount = 0;
  console.log("[Kortix Offscreen] Capture stopped");
}
