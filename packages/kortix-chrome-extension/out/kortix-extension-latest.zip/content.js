var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
class OverlayManager {
  constructor() {
    __publicField(this, "shadowHost", null);
    __publicField(this, "shadowRoot", null);
    __publicField(this, "state", "hidden");
    __publicField(this, "cdpAllowed", false);
    // Bound event handlers for proper cleanup
    __publicField(this, "boundBlockEvent");
    __publicField(this, "boundBlockKeyEvent");
    // All events we need to intercept
    __publicField(this, "MOUSE_EVENTS", [
      "mousedown",
      "mouseup",
      "mousemove",
      "click",
      "dblclick",
      "contextmenu",
      "pointerdown",
      "pointermove",
      "pointerup",
      "drag",
      "dragstart",
      "dragend",
      "dragenter",
      "dragleave",
      "dragover",
      "drop",
      "wheel"
    ]);
    __publicField(this, "KEY_EVENTS", ["keydown", "keyup", "keypress"]);
    this.boundBlockEvent = this.blockEvent.bind(this);
    this.boundBlockKeyEvent = this.blockKeyEvent.bind(this);
  }
  /**
   * Block mouse/pointer events (with CDP bypass)
   */
  blockEvent(e) {
    if (this.cdpAllowed && !e.isTrusted) {
      return;
    }
    if (this.shadowHost && e.composedPath().includes(this.shadowHost)) {
      return;
    }
    if (this.state === "ongoing") {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
    }
  }
  /**
   * Block keyboard events (with CDP bypass)
   */
  blockKeyEvent(e) {
    if (this.cdpAllowed && !e.isTrusted) {
      return;
    }
    if (this.shadowHost && e.composedPath().includes(this.shadowHost)) {
      return;
    }
    if (this.state === "ongoing") {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
    }
  }
  /**
   * Enable full input blocking with CDP bypass
   */
  enableInputBlocking() {
    this.MOUSE_EVENTS.forEach((evt) => {
      window.addEventListener(evt, this.boundBlockEvent, {
        capture: true,
        passive: false
      });
    });
    this.KEY_EVENTS.forEach((evt) => {
      window.addEventListener(evt, this.boundBlockKeyEvent, {
        capture: true,
        passive: false
      });
    });
    this.cdpAllowed = true;
  }
  /**
   * Disable input blocking
   */
  disableInputBlocking() {
    this.MOUSE_EVENTS.forEach((evt) => {
      window.removeEventListener(evt, this.boundBlockEvent, { capture: true });
    });
    this.KEY_EVENTS.forEach((evt) => {
      window.removeEventListener(evt, this.boundBlockKeyEvent, {
        capture: true
      });
    });
    this.cdpAllowed = false;
  }
  /**
   * Show overlay in a specific state
   * @param initialState - The state to initialize with (default: "ongoing")
   */
  show(initialState = "ongoing") {
    if (this.state === initialState) return;
    if (this.state === "hidden") {
      this.createOverlay();
    }
    this.setState(initialState);
    if (initialState === "ongoing") {
      this.enableInputBlocking();
    } else {
      this.disableInputBlocking();
    }
  }
  /**
   * Hide and destroy overlay completely
   */
  hide() {
    this.destroy();
  }
  /**
   * Set overlay state and update UI accordingly
   */
  setState(newState) {
    this.state = newState;
    if (!this.shadowRoot) return;
    const aura = this.shadowRoot.querySelector(".kortix-aura");
    const container = this.shadowRoot.querySelector(
      ".kortix-overlay-container"
    );
    const statusText = this.shadowRoot.querySelector(
      ".status-text"
    );
    const statusIndicator = this.shadowRoot.querySelector(".status-indicator");
    const takeoverBtn = this.shadowRoot.querySelector(
      "#takeover-btn"
    );
    const resumeBtn = this.shadowRoot.querySelector(
      "#resume-btn"
    );
    const modal = this.shadowRoot.querySelector(
      ".kortix-resume-modal"
    );
    switch (newState) {
      case "ongoing":
        if (aura) aura.style.display = "none";
        if (container) container.style.display = "none";
        if (this.shadowRoot) {
          const techOverlays = this.shadowRoot.querySelector(".tech-overlays");
          if (techOverlays) techOverlays.style.display = "none";
        }
        if (statusText) statusText.textContent = "Kortix is browsing...";
        if (statusIndicator) {
          statusIndicator.style.background = "oklch(0.72 0.18 150)";
          statusIndicator.style.boxShadow = "0 0 12px oklch(0.72 0.18 150 / 0.5)";
        }
        if (takeoverBtn) takeoverBtn.style.display = "block";
        if (resumeBtn) resumeBtn.style.display = "none";
        if (modal) modal.classList.add("hidden");
        break;
      case "takeover":
        if (aura) aura.classList.add("paused");
        if (container) container.classList.add("takeover-mode");
        if (statusText)
          statusText.textContent = "User in Control";
        if (statusIndicator) {
          statusIndicator.style.background = "oklch(0.7 0.15 60)";
          statusIndicator.style.boxShadow = "0 0 12px oklch(0.7 0.15 60 / 0.5)";
        }
        if (takeoverBtn) takeoverBtn.style.display = "none";
        if (resumeBtn) resumeBtn.style.display = "block";
        if (modal) modal.classList.add("hidden");
        break;
    }
  }
  /**
   * Toggle visibility for screenshot exclusion (hide overlay from captures)
   */
  setStreamVisibility(visible) {
    if (!this.shadowRoot) return;
    const aura = this.shadowRoot.querySelector(".kortix-aura");
    const pill = this.shadowRoot.querySelector(".kortix-overlay-container");
    const modal = this.shadowRoot.querySelector(".kortix-resume-modal");
    if (visible) {
      aura?.classList.remove("hide-from-stream");
      pill?.classList.remove("hide-from-stream");
      modal?.classList.remove("hide-from-stream");
    } else {
      aura?.classList.add("hide-from-stream");
      pill?.classList.add("hide-from-stream");
      modal?.classList.add("hide-from-stream");
    }
  }
  /**
   * Show the resume modal
   */
  showResumeModal() {
    if (!this.shadowRoot) return;
    const modal = this.shadowRoot.querySelector(
      ".kortix-resume-modal"
    );
    const textarea = this.shadowRoot.querySelector(
      "#resume-summary"
    );
    if (modal) {
      modal.classList.remove("hidden");
      setTimeout(() => textarea?.focus(), 100);
    }
  }
  /**
   * Hide the resume modal
   */
  hideResumeModal() {
    if (!this.shadowRoot) return;
    const modal = this.shadowRoot.querySelector(
      ".kortix-resume-modal"
    );
    const textarea = this.shadowRoot.querySelector(
      "#resume-summary"
    );
    if (modal) {
      modal.classList.add("hidden");
    }
    if (textarea) {
      textarea.value = "";
    }
  }
  /**
   * Create the overlay DOM structure
   */
  createOverlay() {
    this.destroy();
    this.shadowHost = document.createElement("div");
    this.shadowHost.id = "kortix-overlay-host";
    Object.assign(this.shadowHost.style, {
      position: "fixed",
      inset: "0",
      zIndex: "2147483640",
      pointerEvents: "none",
      // Let events pass to our window listeners
      display: "block"
    });
    this.shadowRoot = this.shadowHost.attachShadow({ mode: "closed" });
    const fontUrl = chrome.runtime.getURL(
      "fonts/roobert/RoobertUprightsVF.woff2"
    );
    this.shadowRoot.innerHTML = `
            <style>
                @font-face {
                    font-family: 'Roobert';
                    src: url('${fontUrl}') format('woff2');
                    font-weight: 100 900;
                    font-style: normal;
                }

                :host {
                    all: initial;
                }

                * {
                    box-sizing: border-box;
                }

                .hide-from-stream {
                    visibility: hidden !important;
                    opacity: 0 !important;
                    pointer-events: none !important;
                }

                /* ========== Animations ========== */

                @keyframes slideUp {
                    from { transform: translate(-50%, 60px); opacity: 0; }
                    to { transform: translate(-50%, 0); opacity: 1; }
                }

                @keyframes auraBreath {
                    0%, 100% { transform: scale(1); opacity: 0.6; }
                    50% { transform: scale(1.15); opacity: 0.8; }
                }

                @keyframes auraRotate {
                    from { transform: rotate(0deg); }
                    to { transform: rotate(360deg); }
                }

                @keyframes fadeIn {
                    from { opacity: 0; }
                    to { opacity: 1; }
                }

                @keyframes scanlineMove {
                    0% { transform: translateY(-100%); }
                    100% { transform: translateY(100%); }
                }

                /* ========== Atmospheric Aura ========== */

                .kortix-aura {
                    position: fixed;
                    inset: -50%;
                    width: 200%;
                    height: 200%;
                    background: radial-gradient(
                        circle at center,
                        transparent 20%,
                        oklch(0.12 0.02 285 / 0.15) 50%,
                        oklch(0.1 0.02 285 / 0.4) 100%
                    );
                    pointer-events: none;
                    z-index: 2147483641;
                    transition: opacity 3s cubic-bezier(0.16, 1, 0.3, 1);
                    overflow: hidden;
                    opacity: 1;
                }

                .aura-blobs {
                    position: absolute;
                    inset: 0;
                    animation: auraRotate 80s linear infinite;
                    opacity: 0.3;
                    filter: blur(140px);
                }

                .aura-blob {
                    position: absolute;
                    border-radius: 50%;
                    mix-blend-mode: screen;
                    animation: auraBreath 20s ease-in-out infinite alternate;
                }

                .aura-blob-1 {
                    width: 50%;
                    height: 50%;
                    top: 10%;
                    left: 20%;
                    background: radial-gradient(circle, oklch(0.65 0.3 265 / 0.4), transparent 70%);
                }

                .aura-blob-2 {
                    width: 60%;
                    height: 60%;
                    bottom: 15%;
                    right: 15%;
                    background: radial-gradient(circle, oklch(0.7 0.25 195 / 0.3), transparent 70%);
                    animation-delay: -7s;
                }

                .aura-blob-3 {
                    width: 45%;
                    height: 45%;
                    top: 40%;
                    left: 40%;
                    background: radial-gradient(circle, oklch(0.6 0.25 315 / 0.3), transparent 70%);
                    animation-delay: -14s;
                }

                /* Techy Overlay Layers */
                .tech-overlays {
                    position: fixed;
                    inset: 0;
                    pointer-events: none;
                    z-index: 2147483642;
                }

                .scanlines {
                    position: absolute;
                    inset: 0;
                    background: linear-gradient(
                        to bottom,
                        transparent,
                        oklch(1 0 0 / 0.02) 50%,
                        transparent
                    );
                    background-size: 100% 2px;
                    opacity: 0.2;
                }

                .vignette {
                    position: absolute;
                    inset: 0;
                    background: radial-gradient(
                        circle at center,
                        transparent 40%,
                        oklch(0 0 0 / 0.2) 100%
                    );
                }

                .kortix-aura.paused {
                    opacity: 0.2;
                    filter: grayscale(0.8);
                }
                
                .kortix-aura.paused .aura-blobs {
                   animation-play-state: paused;
                }

                /* ========== Status Pill (Antigravity Style) ========== */

                .kortix-overlay-container {
                    position: fixed;
                    bottom: 48px;
                    left: 50%;
                    transform: translateX(-50%);
                    pointer-events: auto;
                    font-family: 'Roobert', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                    background: oklch(0.18 0.01 285 / 0.75);
                    -webkit-backdrop-filter: blur(32px) saturate(180%);
                    backdrop-filter: blur(32px) saturate(180%);
                    border: 1px solid oklch(1 0 0 / 0.1);
                    border-radius: 9999px;
                    padding: 8px 8px 8px 22px;
                    display: flex;
                    align-items: center;
                    gap: 24px;
                    box-shadow:
                        0 32px 64px -16px oklch(0 0 0 / 0.6),
                        0 0 0 1px oklch(1 0 0 / 0.04) inset;
                    user-select: none;
                    animation: slideUp 1.2s cubic-bezier(0.16, 1, 0.3, 1) forwards;
                    overflow: hidden;
                    white-space: nowrap;
                    z-index: 2147483645;
                    transition: all 0.5s cubic-bezier(0.16, 1, 0.3, 1);
                }

                .kortix-overlay-container.takeover-mode {
                    border-color: oklch(0.7 0.15 60 / 0.25);
                    background: oklch(0.22 0.02 65 / 0.8);
                }

                .grain {
                    position: absolute;
                    inset: 0;
                    opacity: 0.12;
                    pointer-events: none;
                    mix-blend-mode: overlay;
                    background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E");
                }

                .status-group {
                    display: flex;
                    align-items: center;
                    gap: 14px;
                    z-index: 2;
                }

                .status-indicator {
                    width: 10px;
                    height: 10px;
                    border-radius: 50%;
                    background: oklch(0.75 0.25 150);
                    box-shadow: 0 0 16px oklch(0.75 0.25 150 / 0.6);
                    position: relative;
                }

                .takeover-mode .status-indicator {
                    background: oklch(0.75 0.2 65);
                    box-shadow: 0 0 16px oklch(0.75 0.2 65 / 0.6);
                }

                .status-text {
                    color: oklch(0.98 0 0);
                    font-size: 14px;
                    font-weight: 500;
                    letter-spacing: -0.015em;
                }

                .action-btn {
                    background: oklch(0.98 0 0);
                    color: oklch(0.15 0 0);
                    border: none;
                    padding: 10px 22px;
                    border-radius: 9999px;
                    font-size: 13px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
                    z-index: 2;
                    letter-spacing: -0.01em;
                    font-family: inherit;
                    box-shadow: 0 4px 12px oklch(0 0 0 / 0.1);
                }

                .action-btn:hover {
                    transform: scale(1.04) translateY(-1px);
                    background: white;
                    box-shadow: 0 12px 32px -8px oklch(0 0 0 / 0.4);
                }

                .action-btn:active {
                    transform: scale(0.96);
                }

                #resume-btn {
                    background: oklch(0.65 0.25 265);
                    color: white;
                    box-shadow: 0 4px 16px oklch(0.65 0.25 265 / 0.3);
                }

                #resume-btn:hover {
                    background: oklch(0.7 0.28 265);
                    box-shadow: 0 16px 32px -8px oklch(0.65 0.25 265 / 0.5);
                }

                /* ========== Resume Modal ========== */

                .kortix-resume-modal {
                    position: fixed;
                    inset: 0;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    background: oklch(0.05 0 0 / 0.4);
                    -webkit-backdrop-filter: blur(24px);
                    backdrop-filter: blur(24px);
                    z-index: 2147483647;
                    pointer-events: auto;
                    animation: fadeIn 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
                }

                .kortix-resume-modal.hidden {
                    display: none;
                }

                .modal-content {
                    background: oklch(0.15 0.01 285 / 0.85);
                    border: 1px solid oklch(1 0 0 / 0.1);
                    border-radius: 28px;
                    padding: 36px;
                    max-width: 480px;
                    width: 90%;
                    box-shadow: 0 48px 96px -24px oklch(0 0 0 / 0.6);
                    font-family: inherit;
                    position: relative;
                    overflow: hidden;
                }

                .modal-content h3 {
                    margin: 0 0 14px 0;
                    color: oklch(1 0 0);
                    font-size: 22px;
                    font-weight: 600;
                    letter-spacing: -0.025em;
                }

                .modal-content p {
                    margin: 0 0 24px 0;
                    color: oklch(0.85 0 0);
                    font-size: 15px;
                    line-height: 1.6;
                }

                .modal-content textarea {
                    width: 100%;
                    min-height: 140px;
                    padding: 18px;
                    border: 1px solid oklch(1 0 0 / 0.08);
                    border-radius: 20px;
                    background: oklch(1 0 0 / 0.03);
                    color: oklch(1 0 0);
                    font-size: 15px;
                    font-family: inherit;
                    resize: none;
                    outline: none;
                    transition: border-color 0.3s ease, background 0.3s ease;
                }

                .modal-content textarea:focus {
                    border-color: oklch(0.65 0.25 265 / 0.4);
                    background: oklch(1 0 0 / 0.05);
                }

                .modal-actions {
                    display: flex;
                    gap: 14px;
                    margin-top: 32px;
                    justify-content: flex-end;
                }

                .modal-btn {
                    padding: 12px 28px;
                    border-radius: 9999px;
                    font-size: 15px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
                    font-family: inherit;
                    border: none;
                }

                .modal-btn-secondary {
                    background: oklch(1 0 0 / 0.04);
                    color: oklch(0.85 0 0);
                    border: 1px solid oklch(1 0 0 / 0.1);
                }

                .modal-btn-secondary:hover {
                    background: oklch(1 0 0 / 0.08);
                    transform: translateY(-2px);
                }

                .modal-btn-primary {
                    background: oklch(0.98 0 0);
                    color: oklch(0.15 0 0);
                    box-shadow: 0 8px 20px -4px oklch(0.98 0 0 / 0.2);
                }

                .modal-btn-primary:hover {
                    background: white;
                    transform: translateY(-2px);
                    box-shadow: 0 16px 32px -8px oklch(0 0 0 / 0.4);
                }
            </style>

            <div class="kortix-aura">
                <div class="aura-blobs">
                    <div class="aura-blob aura-blob-1"></div>
                    <div class="aura-blob aura-blob-2"></div>
                    <div class="aura-blob aura-blob-3"></div>
                </div>
            </div>

            <div class="tech-overlays">
                <div class="scanlines"></div>
                <div class="vignette"></div>
            </div>

            <!-- Status Pill -->
            <div class="kortix-overlay-container">
                <div class="grain"></div>

                <div class="status-group">
                    <div class="status-indicator"></div>
                    <span class="status-text">Kortix is browsing...</span>
                </div>

                <button class="action-btn" id="takeover-btn">
                    Take Over
                </button>

                <button class="action-btn" id="resume-btn" style="display: none;">
                    Resume Task
                </button>
            </div>

            <!-- Resume Modal -->
            <div class="kortix-resume-modal hidden">
                <div class="modal-content">
                    <div class="grain"></div>
                    <h3>Resume Task</h3>
                    <p>Briefly describe what you changed. This helps your Kortix Worker maintain continuity.</p>
                    <textarea
                        id="resume-summary"
                        placeholder="I updated the shipping address and saved the form..."
                    ></textarea>
                    <div class="modal-actions">
                        <button class="modal-btn modal-btn-secondary" id="cancel-resume-btn">
                            Cancel
                        </button>
                        <button class="modal-btn modal-btn-primary" id="confirm-resume-btn">
                            Confirm & Resume
                        </button>
                    </div>
                </div>
            </div>
        `;
    this.attachEventListeners();
    document.body.appendChild(this.shadowHost);
  }
  /**
   * Attach event listeners to overlay elements
   */
  attachEventListeners() {
    if (!this.shadowRoot) return;
    const takeoverBtn = this.shadowRoot.querySelector("#takeover-btn");
    takeoverBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      console.log("[Kortix Overlay] User requested takeover");
      this.disableInputBlocking();
      this.setState("takeover");
      chrome.runtime.sendMessage({ type: "USER_TAKEOVER" });
    });
    const resumeBtn = this.shadowRoot.querySelector("#resume-btn");
    resumeBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      console.log("[Kortix Overlay] User wants to resume");
      this.showResumeModal();
    });
    const cancelBtn = this.shadowRoot.querySelector("#cancel-resume-btn");
    cancelBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      this.hideResumeModal();
    });
    const confirmBtn = this.shadowRoot.querySelector("#confirm-resume-btn");
    confirmBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      const textarea2 = this.shadowRoot?.querySelector(
        "#resume-summary"
      );
      const summary = textarea2?.value?.trim() || "";
      console.log("[Kortix Overlay] Resuming with summary:", summary);
      this.enableInputBlocking();
      this.setState("ongoing");
      this.hideResumeModal();
      chrome.runtime.sendMessage({
        type: "RESUME_TASK",
        summary
      });
    });
    const modal = this.shadowRoot.querySelector(".kortix-resume-modal");
    modal?.addEventListener("click", (e) => {
      if (e.target === modal) {
        this.hideResumeModal();
      }
    });
    const textarea = this.shadowRoot.querySelector("#resume-summary");
    textarea?.addEventListener("keydown", (e) => {
      const keyEvent = e;
      if (keyEvent.key === "Escape") {
        this.hideResumeModal();
      }
      if (keyEvent.key === "Enter" && (keyEvent.ctrlKey || keyEvent.metaKey)) {
        confirmBtn?.dispatchEvent(new Event("click"));
      }
    });
  }
  /**
   * Clean up and remove overlay
   */
  destroy() {
    this.disableInputBlocking();
    if (this.shadowHost) {
      this.shadowHost.remove();
      this.shadowHost = null;
      this.shadowRoot = null;
    }
    this.state = "hidden";
  }
  /**
   * Get current overlay state
   */
  getState() {
    return this.state;
  }
  /**
   * Check if overlay is currently visible
   */
  isVisible() {
    return this.state !== "hidden";
  }
  /**
   * Check if currently in takeover mode
   */
  isInTakeover() {
    return this.state === "takeover";
  }
}
const overlayManager = new OverlayManager();
class InputHelper {
  /**
   * Set value on a React-controlled input/textarea while bypassing React's value tracker
   * This ensures React recognizes the change and updates its internal state
   */
  static setReactValue(element, value) {
    const lastValue = element.value;
    element.value = value;
    const tracker = element._valueTracker;
    if (tracker) {
      tracker.setValue(lastValue);
    }
    element.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
    element.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
  }
  /**
   * Type text into any element (input, textarea, or contenteditable)
   * Uses native setters to bypass framework protections
   *
   * @param element - The target element to type into
   * @param text - The text to type
   * @param clear - Whether to clear existing content first (default: true)
   */
  static type(element, text, clear = true) {
    element.focus();
    if (element instanceof HTMLInputElement) {
      this.typeIntoInput(element, text, clear);
    } else if (element instanceof HTMLTextAreaElement) {
      this.typeIntoTextArea(element, text, clear);
    } else if (element.isContentEditable) {
      this.typeIntoContentEditable(element, text, clear);
    } else {
      console.warn("[InputHelper] Unknown element type, using textContent fallback");
      element.textContent = text;
    }
  }
  /**
   * Type into an HTMLInputElement using native setter
   */
  static typeIntoInput(input, text, clear) {
    const newValue = clear ? text : input.value + text;
    if (this.nativeInputValueSetter) {
      this.nativeInputValueSetter.call(input, newValue);
    } else {
      input.value = newValue;
    }
    const tracker = input._valueTracker;
    if (tracker) {
      tracker.setValue(clear ? "" : input.value);
    }
    this.dispatchInputEvents(input, text);
  }
  /**
   * Type into an HTMLTextAreaElement using native setter
   */
  static typeIntoTextArea(textarea, text, clear) {
    const newValue = clear ? text : textarea.value + text;
    if (this.nativeTextAreaValueSetter) {
      this.nativeTextAreaValueSetter.call(textarea, newValue);
    } else {
      textarea.value = newValue;
    }
    const tracker = textarea._valueTracker;
    if (tracker) {
      tracker.setValue(clear ? "" : textarea.value);
    }
    this.dispatchInputEvents(textarea, text);
  }
  /**
   * Type into a contenteditable element (rich text editors like DraftJS, ProseMirror, Slate, etc.)
   */
  static typeIntoContentEditable(element, text, clear) {
    if (clear) {
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(element);
      selection?.removeAllRanges();
      selection?.addRange(range);
    } else {
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(element);
      range.collapse(false);
      selection?.removeAllRanges();
      selection?.addRange(range);
    }
    const execSuccess = document.execCommand("insertText", false, text);
    if (!execSuccess) {
      try {
        const inputEvent = new InputEvent("beforeinput", {
          inputType: "insertText",
          data: text,
          bubbles: true,
          cancelable: true
        });
        element.dispatchEvent(inputEvent);
        if (clear) {
          element.textContent = text;
        } else {
          element.textContent = (element.textContent || "") + text;
        }
        element.dispatchEvent(new InputEvent("input", {
          inputType: "insertText",
          data: text,
          bubbles: true
        }));
      } catch (e) {
        if (clear) {
          element.textContent = text;
        } else {
          element.textContent = (element.textContent || "") + text;
        }
      }
    }
  }
  /**
   * Dispatch comprehensive input events for maximum framework compatibility
   */
  static dispatchInputEvents(element, data) {
    try {
      element.dispatchEvent(new InputEvent("beforeinput", {
        inputType: "insertText",
        data,
        bubbles: true,
        cancelable: true
      }));
    } catch (e) {
    }
    element.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
    element.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
  }
  /**
   * Clear an input element
   */
  static clear(element) {
    this.type(element, "", true);
  }
  /**
   * Append text to an existing value without clearing
   */
  static append(element, text) {
    this.type(element, text, false);
  }
  /**
   * Simulate typing character by character with delay (for visual feedback)
   * Useful for demos or when sites detect instant typing as bot behavior
   */
  static async typeSlowly(element, text, delayMs = 50, clear = true) {
    element.focus();
    if (clear) {
      this.clear(element);
    }
    for (const char of text) {
      const variance = Math.random() * 20 - 10;
      await new Promise((resolve) => setTimeout(resolve, delayMs + variance));
      this.append(element, char);
    }
  }
  /**
   * Check if an element is a valid input target
   */
  static isInputElement(element) {
    return element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement;
  }
  /**
   * Check if an element is contenteditable
   */
  static isContentEditable(element) {
    return element instanceof HTMLElement && element.isContentEditable;
  }
  /**
   * Check if an element can receive text input
   */
  static isTypeable(element) {
    return this.isInputElement(element) || this.isContentEditable(element);
  }
}
// Cache native setters for performance
__publicField(InputHelper, "nativeInputValueSetter", Object.getOwnPropertyDescriptor(
  window.HTMLInputElement.prototype,
  "value"
)?.set);
__publicField(InputHelper, "nativeTextAreaValueSetter", Object.getOwnPropertyDescriptor(
  window.HTMLTextAreaElement.prototype,
  "value"
)?.set);
chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
  if (request.type === "SET_OVERLAY_STATE") {
    const { state } = request;
    if (state === "hidden") {
      overlayManager.hide();
    } else {
      overlayManager.show(state);
    }
    sendResponse({ success: true });
    return false;
  }
  if (request.type === "SET_OVERLAY_VISIBILITY") {
    overlayManager.setStreamVisibility(request.visible);
    sendResponse({ success: true });
    return false;
  }
  if (request.type === "executeCommand") {
    executeCommand(request.command).then((result) => {
      sendResponse({ success: true, data: result });
    }).catch((error) => {
      sendResponse({
        success: false,
        error: error.message
      });
    });
    return true;
  }
});
async function executeCommand(command) {
  const { action, params } = command;
  switch (action) {
    case "navigate":
      return handleNavigate(params);
    case "click":
      return handleClick(params);
    case "type":
      return handleType(params);
    case "scroll":
      return handleScroll(params);
    case "hover":
      return handleHover(params);
    case "screenshot":
      return handleScreenshot();
    case "extractEmails":
      return handleExtractEmails();
    case "extractContent":
      return handleExtractContent(params);
    case "getElements":
      return handleGetElements();
    case "fillForm":
      return handleFillForm(params);
    case "submitForm":
      return handleSubmitForm(params);
    case "getPageInfo":
      return handleGetPageInfo();
    case "executeScript":
      return handleExecuteScript(params);
    default:
      throw new Error(`Unknown action: ${action}`);
  }
}
async function handleNavigate(params) {
  const { url } = params;
  if (!url) {
    throw new Error("URL parameter required");
  }
  window.location.href = url;
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        url: window.location.href,
        title: document.title
      });
    }, 2e3);
  });
}
async function handleClick(params) {
  const { selector, index } = params;
  let element = null;
  if (selector) {
    element = document.querySelector(selector);
  } else if (index !== void 0) {
    const elements = document.querySelectorAll(
      'a, button, input, [role="button"]'
    );
    element = elements[index];
  }
  if (!element) {
    throw new Error("Element not found");
  }
  element.click();
  await new Promise((resolve) => setTimeout(resolve, 500));
  return {
    clicked: true,
    element: element.tagName
  };
}
async function handleHover(params) {
  const { selector } = params;
  if (!selector) {
    throw new Error("Selector parameter required");
  }
  const element = document.querySelector(selector);
  if (!element) {
    throw new Error("Element not found");
  }
  element.dispatchEvent(new MouseEvent("mouseover", { bubbles: true }));
  element.dispatchEvent(new MouseEvent("mouseenter", { bubbles: true }));
  element.dispatchEvent(new MouseEvent("mousemove", { bubbles: true }));
  return {
    hovered: true,
    element: element.tagName
  };
}
async function handleType(params) {
  const { selector, text, index, clear = true } = params;
  let element = null;
  if (selector) {
    element = document.querySelector(selector);
  } else if (index !== void 0) {
    const elements = document.querySelectorAll(
      'input, textarea, [contenteditable="true"]'
    );
    element = elements[index];
  }
  if (!element) {
    throw new Error("Element not found");
  }
  if (!InputHelper.isTypeable(element)) {
    throw new Error("Element is not a valid input target");
  }
  InputHelper.type(element, text, clear);
  const resultValue = element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement ? element.value : element.textContent || "";
  return {
    typed: true,
    value: resultValue
  };
}
async function handleScroll(params) {
  const { direction, amount = 500 } = params;
  if (direction === "down") {
    window.scrollBy(0, amount);
  } else if (direction === "up") {
    window.scrollBy(0, -amount);
  } else if (direction === "top") {
    window.scrollTo(0, 0);
  } else if (direction === "bottom") {
    window.scrollTo(0, document.body.scrollHeight);
  }
  await new Promise((resolve) => setTimeout(resolve, 300));
  return {
    scrolled: true,
    scrollY: window.scrollY
  };
}
async function handleScreenshot(_params) {
  try {
    const canvas = await html2canvas(document.body);
    const dataUrl = canvas.toDataURL("image/png");
    return {
      screenshot: dataUrl,
      width: canvas.width,
      height: canvas.height
    };
  } catch (error) {
    console.warn(
      "[Kortix Extension - Content] Screenshot failed, using fallback"
    );
    return {
      screenshot: null,
      error: "Screenshot not available",
      fallback: true
    };
  }
}
async function handleExtractEmails(_params) {
  const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
  const bodyText = document.body.innerText;
  const emailsFromText = bodyText.match(emailRegex) || [];
  const mailtoLinks = Array.from(
    document.querySelectorAll('a[href^="mailto:"]')
  ).map((a) => {
    const href = a.href;
    return href.replace("mailto:", "").split("?")[0];
  });
  const dataAttributeEmails = Array.from(
    document.querySelectorAll("[data-email]")
  ).map((el) => el.getAttribute("data-email")).filter((email) => email !== null && email !== "");
  const allEmails = [
    .../* @__PURE__ */ new Set([...emailsFromText, ...mailtoLinks, ...dataAttributeEmails])
  ];
  return {
    emails: allEmails,
    count: allEmails.length,
    sources: {
      text: emailsFromText.length,
      mailto: mailtoLinks.length,
      dataAttributes: dataAttributeEmails.length
    }
  };
}
async function handleExtractContent(params) {
  const { selector } = params;
  let content = "";
  if (selector) {
    const element = document.querySelector(selector);
    content = element?.textContent || "";
  } else {
    content = document.body.innerText;
  }
  return {
    content: content.trim(),
    length: content.length
  };
}
async function handleGetElements(_params) {
  const elements = document.querySelectorAll(
    'a, button, input, textarea, select, [role="button"], [role="link"]'
  );
  const elementsList = Array.from(elements).slice(0, 100).map((el, index) => ({
    index,
    tag: el.tagName.toLowerCase(),
    text: el.textContent?.substring(0, 100) || "",
    type: el.type || "",
    href: el.href || "",
    id: el.id || "",
    className: el.className || ""
  }));
  return {
    elements: elementsList,
    total: elements.length
  };
}
async function handleFillForm(params) {
  const { fields } = params;
  if (!fields || typeof fields !== "object") {
    throw new Error("Fields parameter required");
  }
  const results = {};
  for (const [selector, value] of Object.entries(fields)) {
    const element = document.querySelector(selector);
    if (!element) {
      results[selector] = { success: false, error: "Element not found" };
      continue;
    }
    if (element instanceof HTMLElement) {
      InputHelper.type(element, String(value), true);
      const resultValue = element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement ? element.value : element.textContent || "";
      results[selector] = { success: true, value: resultValue };
    } else {
      results[selector] = { success: false, error: "Element is not an HTMLElement" };
    }
  }
  return results;
}
async function handleSubmitForm(params) {
  const { selector } = params;
  const form = selector ? document.querySelector(selector) : document.querySelector("form");
  if (!form) {
    throw new Error("Form not found");
  }
  form.submit();
  await new Promise((resolve) => setTimeout(resolve, 1e3));
  return {
    submitted: true,
    url: window.location.href
  };
}
async function handleGetPageInfo(_params) {
  return {
    title: document.title,
    url: window.location.href,
    domain: window.location.hostname,
    protocol: window.location.protocol,
    scrollY: window.scrollY,
    scrollHeight: document.body.scrollHeight,
    innerHeight: window.innerHeight,
    innerWidth: window.innerWidth,
    readyState: document.readyState
  };
}
async function handleExecuteScript(params) {
  const { code } = params;
  if (!code) {
    throw new Error("Code parameter required");
  }
  try {
    const result = new Function(code)();
    return {
      success: true,
      result
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : "Script execution failed"
    };
  }
}
async function html2canvas(_element) {
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  if (ctx) {
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#000000";
    ctx.font = "16px Arial";
    ctx.fillText(`Screenshot: ${document.title}`, 10, 30);
  }
  return canvas;
}
chrome.runtime.sendMessage({ type: "GET_OVERLAY_STATE" }, (response) => {
  if (response && response.state && response.state !== "hidden") {
    console.log("[Kortix Extension - Content] Restoring overlay state:", response.state);
    overlayManager.show(response.state);
  }
});
console.log("[Kortix Extension - Content] Content script loaded");
