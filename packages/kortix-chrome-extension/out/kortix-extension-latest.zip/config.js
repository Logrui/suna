const ENV = {
  // These MUST be provided at build time via .env or environment variables
  FRONTEND_URL: "https://suna.syhc.dev",
  BACKEND_URL: "https://api.suna.syhc.dev/v1",
  IS_DEV: !chrome.runtime.getManifest().update_url
};
const getApiUrl = () => {
  const url = ENV.BACKEND_URL;
  return url.endsWith("/v1") ? url.slice(0, -3) : url;
};
const getWsUrl = () => {
  return ENV.BACKEND_URL.replace(/^http/, "ws") + "/ws/extension";
};
function getConfig() {
  return {
    apiUrl: getApiUrl(),
    wsUrl: getWsUrl(),
    frontendUrl: ENV.FRONTEND_URL
  };
}
function getConnectBrowserUrl() {
  const config = getConfig();
  return `${config.frontendUrl}/connect-browser`;
}
export {
  getConnectBrowserUrl as a,
  getConfig as g
};
